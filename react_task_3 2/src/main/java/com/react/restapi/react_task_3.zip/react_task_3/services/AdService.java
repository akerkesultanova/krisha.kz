package com.react.restapi.react_task_3.services;

import com.react.restapi.react_task_3.entities.Ad;

import java.util.List;

public interface AdService {
    List<Ad> getAllAd();
    List<Ad> searchAd(String name);
    Ad addAd(Ad ad);
    Ad editAd(Ad ad);
    Ad getAd(Long id);
    void deleteAd(Ad ad);
}

