package com.react.restapi.react_task_3.services.impl;


import com.react.restapi.react_task_3.entities.Ad;
import com.react.restapi.react_task_3.repositories.AdRepository;
import com.react.restapi.react_task_3.services.AdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdServiceImpl implements AdService {

    @Autowired
    private AdRepository adRepository;

    @Override
    public List<Ad> getAllAd() {
        return adRepository.findAll();
    }

    @Override
    public List<Ad> searchAd(String name) {
        return null;
    }

    @Override
    public Ad addAd(Ad ad) {
        return adRepository.save(ad);
    }

    @Override
    public Ad editAd(Ad ad) {
        return adRepository.save(ad);
    }

    @Override
    public Ad getAd(Long id) {
        Optional<Ad> opt = adRepository.findById(id);
        return opt.isPresent()?opt.get():null;
    }

    @Override
    public void deleteAd(Ad ad) {
        adRepository.delete(ad);
    }
}
