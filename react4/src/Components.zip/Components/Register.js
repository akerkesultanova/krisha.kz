import { Carousel } from 'materialize-css';
import React, { Component, useState } from 'react';
import M from 'materialize-css'


function Register(props) {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [repassword, setRepassword] = useState("");
    const [fullName, setFullName] = useState("");

    const handleChange = event => {
        if(event.target.name=="full_name"){
            setFullName(event.target.value);
        }
        else if(event.target.name=="email"){
            setEmail(event.target.value);
        }
        else if(event.target.name=="password"){
            setPassword(event.target.value);
        }
        if(event.target.name=="repassword"){
            setRepassword(event.target.value);
        }
    }

    const handleSubmit = event => {
        const userData = {email,password,fullName}
        if(password != repassword){
            M.toast({html: "<i class='small material-icons left'>warning</i><strong style='font-weight:bolds'>Wrong Re-Password</strong>", classes:'center yellow darken-4 rounded'});
        }
        else{
            if(email=="" || password=="" || fullName==""){
                M.toast({html: "<i class='small materials-icons left'>warning</i><strong>Fill all inputs</strong>", classes:'center yellow darken-4 rounded'});
            }
            else{
                register(userData);
            }
        }
        event.preventDefault();
    }


    async function register(userData){
        const response = await fetch("http://localhost:8000/api/register", {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json"
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(userData)
        });
        if(response.status==200){
            M.toast({html: "<i class='small materials-icons left'>warning</i><strong>You have successfully registeres!</strong></strong>", classes:'center green darken-4 rounded'});
        }
        else{
            M.toast({html: "<i class='small materials-icons left'>warning</i><strong>This user already exists!</strong>", classes:'center red darken-4 rounded'});
        }
    }



        return (
            <div className="container">
                <div className='row'>
                    <div className="input-field col s6 offset-s3">
                            <blockquote>
                                <h4>Create new account</h4>
                            </blockquote>
                    </div>
                        <form className="col s6 offset-s3" onSubmit={handleSubmit}>
                                <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>account_circle</i>
                                <input id="icon_prefix" value={fullName} name="full_name" onChange={handleChange} type="text" className="validate"/>
                                <label for="icon_prefix">First Name</label>
                            </div>
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>email</i>
                                <input id="email" type="email" value={email} name="email" onChange={handleChange} class="validate"/>
                                <label for="email">Email</label>
                            </div>
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>lock</i>
                                <input id="password" type="password" value={password} name="password" onChange={handleChange}  className="validate"/>
                                <label for="password">Password</label>
                            </div>
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>lock</i>
                                <input id="repassword" type="password" value={repassword} name="repassword" onChange={handleChange} claclassNamess="validate"/>
                                <label for="repassword">Repeat password</label>
                            </div>
                            <div className='input-field row'>
                                <p>
                                    <label>
                                        <input type="checkbox" />
                                        <span>I have read and accepted the terms and conditions</span>
                                    </label>
                                </p>
                            </div>
                            <div className='input-field row'>
                            
                            <button class="btn waves-effect waves-light right" type="submit" name="action" style={{backgroundColor: 'blue'}}>Register
                                <i class="material-icons right">send</i>
                            </button>
                            </div>
                        </form>
                </div>
            </div>
        );
    }

export default Register;