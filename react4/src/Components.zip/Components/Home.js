import { Carousel } from 'materialize-css';
import React, { Component } from 'react';
import Carousell from './Carousel';


function Home(props) {
        return (
            <div className="container">
                <div className="row">
                <Carousell/>
                </div>
                <div className="row">
                <ul className="collection">
                    <li className="collection-item avatar">
                    <i class="material-icons circle" style={{backgroundColor: 'blue'}}>access_time</i>
                    <span className="title">Quick Access</span>
                    <p>Fast and easy
                    </p>
                    <a href="#!" className="secondary-content"><i className="material-icons">check</i></a>
                    </li>
                    <li className="collection-item avatar">
                    <i className="material-icons circle" style={{backgroundColor: 'yellow'}}>folder</i>
                    <span className="title">Great Management</span>
                    <p>Grouping your tasks
                    </p>
                    <a href="#!" className="secondary-content"><i className="material-icons">check</i></a>
                    </li>
                    <li className="collection-item avatar">
                    <i className="material-icons circle green" style={{backgroundColor: 'green'}}>insert_chart</i>
                    <span className="title">Statistics</span>
                    <p>Monitoring with your success
                    </p>
                    <a href="#!" className="secondary-content"><i className="material-icons">check</i></a>
                    </li>
                    <li className="collection-item avatar">
                    <i className="material-icons circle red">cloud_upload</i>
                    <span className="title">Cloud Service</span>
                    <p>Store your data in cloud
                    </p>
                    <a href="#!" className="secondary-content"><i className="material-icons">check</i></a>
                    </li>
                </ul>
                </div>
            </div>
        
        );
    }

export default Home;