import { Carousel } from 'materialize-css';
import React, { Component, useContext, useEffect } from 'react';
import {UserContext} from './Navbar';
import { useCookies } from 'react-cookie';
import M from 'materialize-css';

function Login(props) {
    const context = useContext(UserContext);


    async function login(userData){
        const response = await fetch("http://localhost:8000/auth", {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json"
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: JSON.stringify(userData)
        });
        if(response.status==200){
            const jwt = await response.json();
            context.setCookieJwt('jwt', jwt);
            profile(jwt);
            context.setIsonline(true);
            
        }
    }

    async function profile(jwt){
        const bearer = "Bearer " + jwt.jwtToken;
        console.log(jwt);
        const response = await fetch("http://localhost:8000/api/profile", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Authorization":bearer
        },
        });
        if(response.status==200){
            let userData = await response.json();
            console.log(userData);
            context.setEmail(userData.email);
            context.setPassword(userData.password);
            context.setFullName(userData.fullName);
        }
    }

    useEffect(()=>{
        M.updateTextFields();
    })

    const handleSubmit = event => {
        const userData = {email:context.email,password:context.password}
        login(userData);
        event.preventDefault();
    }
    
        return (
            <div className="container">
                <div className='row'>
                    <div className="input-field col s6 offset-s3">
                        <blockquote>
                            <h4>Sign in</h4>
                        </blockquote>
                                </div>
                        <form className="col s6 offset-s3" onSubmit={handleSubmit}>
                                <div className="input-field row">
                                    <i className="material-icons prefix" style={{color: 'blue'}}>email</i>
                                    <input id="email" type="email" name="email" value={context.email} onChange={context.handleChange} class="validate"/>
                                    <label className="active" for="email">Email</label>
                                </div>
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>lock</i>
                                <input id="password" type="password" name="password" value={context.password} onChange={context.handleChange} className="validate"/>
                                <label className="active" for="password">Password</label>
                            </div>
                            <div className='input-field row'>
                                <p>
                                    <label>
                                        <input type="checkbox" name="remember" ckecked={context.remember} onChange={context.handleChange}/>
                                        <span>Remember me</span>
                                    </label>
                                </p>
                            </div>
                            <div className="input-field row">
                            <button class="btn waves-effect waves-light right" type="submit" name="action" style={{backgroundColor: 'blue'}}>Login
                                <i class="material-icons right">send</i>
                            </button>
                            </div>
                        </form>
                </div>
            </div>
        );
    }

export default Login;