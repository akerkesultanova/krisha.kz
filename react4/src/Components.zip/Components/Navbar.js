import React, { Component, useState } from 'react';
import { Link, Route,BrowserRouter as Router, Switch, Redirect } from 'react-router-dom';
import Content from './Content';
import Details from './Details';
import Home from './Home';
import Register from './Register';
import Login from './Login';
import Profile from './Profile';
import { useCookies } from 'react-cookie';

export const UserContext = React.createContext();


function Navbar(props) {
    const [cookieJwt, setCookieJwt, removeCookieJwt] = useCookies(["jwt"]);
    const[isOnline, setIsonline] = useState(false);
    const [remember, setRemember] = useState(false);
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [fullName, setFullName] = useState("");

    const handleChange = event => {
      if(event.target.name=="full_name"){
          setFullName(event.target.value);
      }
      else if(event.target.name=="email"){
          setEmail(event.target.value);
      }
      else if(event.target.name=="password"){
          setPassword(event.target.value);
      }
      else if(event.target.name=="remember"){
        setRemember(!remember);
      }
  }

  

  function logout(){
    if(!remember){
      setEmail("");
      setFullName("");
      setPassword("");
      removeCookieJwt("jwt");
    }
    setIsonline(false);
  }
  
        return (<Router>

        
        <div className="row">

       
        <nav className="indigo darken-3" role="navigation">
                    <div className="nav-wrapper container">
                    <a href="/" id="logo-container" className="brand-logo" style={{fontWeight:"bold"}}>ITrello</a>
                    <ul id="nav-mobile" className="right hide-on-med-and-down">
                        {isOnline?<li> <Link to="/all_cards">All Cards</Link></li>:""}
                        {isOnline?"":<li><Link to="/register">Register</Link></li>}
                        {isOnline?"":<li><Link to="/login">Login</Link></li>}
                        {isOnline?<li><Link to="/profile">{fullName}</Link></li>:""}
                        {isOnline?<li><Link to="/" onClick={logout}>Logout</Link></li>:""}
                    </ul>
                    </div>
            </nav>
            </div>
            <UserContext.Provider value={{
              isOnline:isOnline,
              email:email,
              fullName:fullName,
              password:password,
              handleChange:handleChange,
              setIsonline:setIsonline,
              cookieJwt: cookieJwt,
              setCookieJwt: setCookieJwt,
              removeCookieJwt: removeCookieJwt,
              remember:remember,
              setEmail:setEmail,
              setPassword:setPassword,
              setFullName:setFullName
            }}>

            
            <Switch>
            
              <Route path={`/details/:cardId`}>
                <Details/>
              </Route>
              <Route path="/login">
                {isOnline?<Redirect to="/all_cards"/>:<Login/>}
              </Route>
              <Route path="/register">
              <Register/>
              </Route>
              <Route path="/all_cards">
                <Content/>
              </Route>
              <Route path="/profile">
                <Profile/>
              </Route>
              <Route path="/">
                <Home/>
              </Route>
  
            </Switch>
            </UserContext.Provider>



            </Router>

            
        );
    }


export default Navbar;






