import React from 'react';
import { Button, Icon } from 'react-materialize';

function CreateTask(props) {
    return (props.msg==""?
    <div className="row">
    <div className="card">
    
      <div className="card-content">
      <form onSubmit={props.handleSubmitTask}>
      <div className="input-field">
          <input id="card" value={props.taskText} onChange={props.handleTaskTextChange} name="taskName" type="text" className="validate"/>
          <label htmlFor="card">Create new task</label>
          
          </div>
          <Button waves="light">ADD NEW TASK</Button>
      </form>
          
      </div>
    </div>
</div>
         :
         <div>
         </div>

  
        
    );
}

export default CreateTask;