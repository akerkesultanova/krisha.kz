import { Carousel } from 'materialize-css';
import React, { Component, useContext } from 'react';
import { UserContext } from './Navbar';


function Profile(props) {
    const context = useContext(UserContext);

        return (
            <div className="container">
                <div className='row'>
                    <div className="input-field col s6 offset-s3">
                        <blockquote>
                            <h4>Update Profile Data</h4>
                        </blockquote>
                                </div>
                        <form className="col s6 offset-s3">
                                <div className="input-field row">
                                    <i className="material-icons prefix" style={{color: 'blue'}}>email</i>
                                    <input id="email" type="email" value={context.email} class="validate"/>
                                    <label for="email">Email</label>
                                </div>
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>account_circle</i>
                                <input id="full_name" type="text" name="full_name" value={context.fullName} onchange={context.handleChange} className="validate"/>
                                <label for="full_name">Full Name</label>
                            </div>
                            <div className="input-field row">
                            <button class="btn waves-effect waves-light right" type="submit" name="action" style={{backgroundColor: 'blue'}}>Update Profile
                                <i class="material-icons right">refresh</i>
                            </button>
                            </div>
                        </form>
                </div>
                <div className='row'>
                    <div className="input-field col s6 offset-s3">
                        <blockquote>
                            <h4>Update Password</h4>
                        </blockquote>
                                </div>
                        <form className="col s6 offset-s3">
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>lock</i>
                                <input id="email" type="email" className="validate"/>
                                <label for="email">Old password</label>
                            </div>
                    
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>lock</i>
                                <input id="email" type="email" className="validate"/>
                                <label for="email">New password</label>
                            </div>
                            <div className="input-field row">
                                <i className="material-icons prefix" style={{color: 'blue'}}>lock</i>
                                <input id="email" type="email" className="validate"/>
                                <label for="email">Repeat new password</label>
                            </div>
                            <div className="input-field row">
                            <button class="btn waves-effect waves-light right" type="submit" name="action" style={{backgroundColor: 'blue'}}>Update Password
                                <i class="material-icons right">refresh</i>
                            </button>
                            </div>
                        </form>
                </div>
            </div>
        );
    }

export default Profile;